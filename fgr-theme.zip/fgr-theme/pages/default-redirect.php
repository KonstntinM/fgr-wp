<?php
#wp_redirect( home_url() );
#exit;
?>
